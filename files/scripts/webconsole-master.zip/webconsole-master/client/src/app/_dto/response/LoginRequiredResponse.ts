import { WebSocketResponse } from "./WebSocketResponse";

export interface LoginRequiredResponse extends WebSocketResponse{
	
}