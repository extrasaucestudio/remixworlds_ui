export interface SettingsDto {
	dateTimePrefix: boolean;
	retrieveLogFile: boolean;
	blurryUri: boolean;
	widerViewport: boolean;
}