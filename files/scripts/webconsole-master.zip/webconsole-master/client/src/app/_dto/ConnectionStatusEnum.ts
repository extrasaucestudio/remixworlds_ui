export enum ConnectionStatusEnum {
	Connecting = 1,
	Connected = 2,
	Disconnected = 3
}