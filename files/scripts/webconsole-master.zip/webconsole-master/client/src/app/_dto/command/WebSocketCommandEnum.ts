export enum WebSocketCommandEnum {
	Login = "LOGIN",
	Exec = "EXEC",
	Players = "PLAYERS",
	CpuUsage = "CPUUSAGE",
	RamUsage = "RAMUSAGE",
	Tps = "TPS",
	ReadLogFile = "READLOGFILE"
}