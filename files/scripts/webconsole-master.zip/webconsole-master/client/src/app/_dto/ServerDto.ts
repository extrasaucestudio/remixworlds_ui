export interface ServerDto {
	serverName: string;
	serverURI: string;
	serverPassword?: string;
}