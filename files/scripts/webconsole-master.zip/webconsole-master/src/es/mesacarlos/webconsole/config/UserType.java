package es.mesacarlos.webconsole.config;

public enum UserType {
	ADMIN,
	VIEWER
}